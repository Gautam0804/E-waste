import { useEffect, useState } from "react";
import Home from "./Components";
import { isAuthenticated } from "./sign-in/auth";

export default function App() {

  return (
    <>
      <Home/>
    </>
  );
}
